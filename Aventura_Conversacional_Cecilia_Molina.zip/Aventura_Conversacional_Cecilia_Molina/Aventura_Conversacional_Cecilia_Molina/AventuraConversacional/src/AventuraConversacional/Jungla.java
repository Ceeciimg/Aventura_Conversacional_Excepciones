package AventuraConversacional;

public class Jungla extends Escenario {

    public Jungla() {
        super("Jungla", "La jungla es densa y peligrosa.");
        
    }
}
