package AventuraConversacional;

public class Playa extends Escenario {

    public Playa() {
        // se llama al constructor de la clase escenario
        super("Playa", "Hay restos de un naufragio.");        
        
    }
}
